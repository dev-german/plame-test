import zlib from 'zlib';
import { visit } from 'unist-util-visit';
import axios from 'axios';

console.log("🚀 PlantUML Plugin is LOADED!"); // 🔍 Debugging

function encodeForPlantUML(umlText) {
  const deflated = zlib.deflateRawSync(Buffer.from(umlText, 'utf-8'));
  return encode64(deflated);
}

// PlantUML usa una variante especial de Base64
function encode64(data) {
  const alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_";
  let result = "";
  let current = 0;
  let bits = 0;

  for (let i = 0; i < data.length; i++) {
    current = (current << 8) | data[i];
    bits += 8;
    while (bits >= 6) {
      bits -= 6;
      result += alphabet[(current >> bits) & 0x3F];
    }
  }

  if (bits > 0) {
    result += alphabet[(current << (6 - bits)) & 0x3F];
  }

  return result;
}

const plugin = (options) => {
  const serverUrl = options?.server || 'http://localhost:8080';

  return async (tree) => {
    const promises = [];
    
    visit(tree, 'code', (node, index, parent) => {
      if (node.lang === 'plantuml') {
        console.log("📌 Found PlantUML Code:", node.value); // 🔍 Debugging: Log the UML code

        const encodedDiagram = encodeForPlantUML(node.value);
        const url = `${serverUrl}/svg/${encodedDiagram}`;

        console.log("🔗 Generated PlantUML URL:", url);  // 🔍 Debugging: Log the final URL

        promises.push(
          (async () => {
            try {
              await axios.head(url);
            //   node.type = 'jsx';              
            //   node.value = `<img src="${url}" alt="PlantUML Diagram" style="max-width: 100%" />`;
            //   node.value = `![PlantUML Diagram](${url})`;
            parent.children[index] = {
                type: 'mdxJsxFlowElement',
                name: 'img',
                attributes: [
                  { type: 'mdxJsxAttribute', name: 'src', value: url },
                  { type: 'mdxJsxAttribute', name: 'alt', value: 'PlantUML Diagram' },
                  { type: 'mdxJsxAttribute', name: 'style', value: 'max-width: 100%;' }
                ],
              };
            } catch (error) {
              console.error("❌ Error processing PlantUML:", error);
            }
          })()
        );
      }
    });

    await Promise.all(promises);
  };
};

export default plugin;
